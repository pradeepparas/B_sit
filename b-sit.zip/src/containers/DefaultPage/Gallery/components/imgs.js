export default [
  { src: `${process.env.PUBLIC_URL}/img/gallery/01.png`, type: 'sneakers', alt: 'sneakers' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/02.png`, type: 'sneakers', alt: 'sneakers' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/03.png`, type: 'sneakers', alt: 'sneakers' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/04.png`, type: 'cap', alt: 'cap' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/05.png`, type: 'watch', alt: 'watch' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/06.png`, type: 'sneakers', alt: 'sneakers' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/07.png`, type: 'sneakers', alt: 'sneakers' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/08.png`, type: 'sneakers', alt: 'sneakers' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/09.png`, type: 'glasses', alt: 'glasses' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/10.png`, type: 'glasses', alt: 'glasses' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/11.png`, type: 'glasses', alt: 'glasses' },
  { src: `${process.env.PUBLIC_URL}/img/gallery/12.png`, type: 'glasses', alt: 'glasses' },
];
